-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 08:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `username`, `password`) VALUES
(1, 'Administrator', 'Admin', 'admin'),
(2, 'hussein', 'hussein', '123');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_id` int(11) NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `middlename` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `lastname` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contactno` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `days` int(40) NOT NULL,
  `extra_beds` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `firstname`, `middlename`, `lastname`, `address`, `contactno`, `days`, `extra_beds`) VALUES
(1, 'hussein', 'saleem', 'rio', 'd', '07812345678', 1, 1),
(2, 'husseinn', 'saleem', 'rio', 'd', '07812345678', 2, 2),
(3, 'husseinn', 'saleem', 'rio', 'd', '07812345678', 2, 2),
(4, 'husseinn', 'saleem', 'rio', 'd', '07812345678', 2, 2),
(5, 'rio', 'saleem', 'rio', 'd', '07812345678', 3, 3),
(6, 'hussein', 'saleem', 'rio', 'd', '078123456232', 9, 5),
(7, 'hussein', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(8, 'husseinnn', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(9, 'husseinnnnn', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(10, 'husseinnnnnتلاتت', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(11, 'husseinnnnnتلاتت', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(12, 'husseinnnnnتلاتتbjjg', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(13, 'ugugugg', 'saleem', 'rio', 'd', '078123456232', 7, 3),
(14, 'hvhg', 'fadhel', 'mask', 'd', '298374', 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `photo` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Hotel_name` varchar(99) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_type`, `price`, `photo`, `Hotel_name`) VALUES
(8, '', '50', 'r.jpg', 'فندق روتانا اربيل'),
(9, '', '60', '12.jpg', 'فندق عنكاوه رويال اربيل'),
(10, '', '50', 'd.jpg', 'فندق كريستال اربيل'),
(11, '', '55', 'da.jpg', 'فندق الماس اربيل'),
(12, '', '49', 'كانيون.jpg', 'فندق كانيون اربيل'),
(13, '', '69', 'ديفان.jpg', ' فندق ديفان أربيل');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `room_no` int(5) NOT NULL,
  `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `checkin` date NOT NULL,
  `checkin_time` time NOT NULL,
  `checkout` date NOT NULL,
  `checkout_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `guest_id`, `room_id`, `room_no`, `status`, `checkin`, `checkin_time`, `checkout`, `checkout_time`) VALUES
(1, 1, 6, 1, 'Check Out', '2024-04-21', '17:13:41', '2024-04-20', '17:21:17'),
(2, 2, 6, 2, 'Check Out', '2024-04-23', '17:24:43', '1970-01-01', '17:24:49'),
(3, 5, 6, 1, 'Check Out', '2024-04-23', '17:25:39', '1970-01-01', '17:25:42'),
(4, 6, 7, 3, 'Check Out', '2024-04-23', '17:37:04', '1970-01-01', '17:37:23'),
(5, 6, 12, 1, 'Check Out', '2024-04-22', '01:52:27', '1970-01-01', '01:53:01'),
(10, 13, 12, 3, 'Check Out', '2024-06-07', '01:52:57', '1970-01-01', '01:53:08'),
(11, 14, 12, 3, 'Check Out', '2024-04-26', '06:26:00', '1970-01-01', '06:26:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
