<?php
require_once 'connect.php'; // تأكد من أن هذا الملف يستخدم mysqli

// تأكد من وجود room_id في الطلب
if(isset($_REQUEST['room_id'])) {
    $room_id = $_REQUEST['room_id'];

    // استخدام استعلام مُعد مسبقًا لزيادة الأمان
    $stmt = $conn->prepare("DELETE FROM `room` WHERE `room_id` = ?");
    $stmt->bind_param("i", $room_id); // "i" تعني أن المتغير نوعه integer

    if($stmt->execute()) {
        header("Location: room.php"); // إعادة توجيه إذا تم الحذف بنجاح
    } else {
        die("Error deleting record: " . $conn->error); // عرض رسالة الخطأ
    }

    $stmt->close(); // إغلاق الاستعلام
} else {
    echo "Room ID is required"; // إذا لم يتم توفير room_id
}

$conn->close(); // إغلاق الاتصال بقاعدة البيانات
?>